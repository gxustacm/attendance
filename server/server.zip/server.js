import express from 'express'
import cookies from 'cookie-parser'
import cors from 'cors'
import dotenv from 'dotenv'
import mysql from 'mysql'
import crypto from 'crypto'
import bodyParser from 'body-parser'
import compression from 'compression'
import { Server } from 'socket.io'
import http from 'http'
import mailin from 'mailin'

dotenv.config()
const app = express()
app.use(compression())
app.use(cookies())
app.use(cors())
app.use(bodyParser.urlencoded({ extended: 'true' }))
app.use(bodyParser.json({ extended: 'true' }))
const server = http.createServer(app)
const io = new Server(server, { cors: true })

mailin.start({
  host: "0.0.0.0",
  port: 25,
  disableWebhook: true
})

mailin.on('message', (conn, data) => {
  console.log(data)
  let to = data.headers.to
  let exp = /[\w\._\-\+]+@[\w\._\-\+]+/i
  if(exp.test(to)) {
    let matches = to.match(exp);
    let shortid = matches[0].substring(0, matches[0].indexOf('@'));
    io.sockets.emit(shortid, data.headers.from)
  }
})

var userList = {}

const encrypt = (str) => {
  const md5 = crypto.createHash('md5')
  return md5.update(str).digest('hex').toUpperCase()
}

io.on('connection', (socket) => {
  socket.on('getUser', (msg) => {
    if (msg in userList) {
      socket.emit('matched', encrypt(userList[msg]))
    }
    else {
      socket.emit('matched', 'nomatch')
    }
  })

  socket.on('check invite code', (msg) => {
    const queryParams = [msg]
    connection.query('select count(*) from `codes` where `code` = ?', queryParams, (err, rows) => {
      if (err)
      {
        socket.emit('invite code stat', 'invalid')
        throw err
      }
      if (rows[0]['count(*)']) {
        socket.emit('invite code stat', 'valid')
      }
      else {
        socket.emit('invite code stat', 'invalid')
      }
    })
  })
})

const connection = mysql.createConnection({
  host: process.env.SQL_HOST,
  user: process.env.SQL_USER,
  password: process.env.SQL_PWD,
  database: process.env.SQL_NAME
})

connection.connect((err) => {
  if (err) {
    console.log('\x1B[31m[Erro] \x1B[0m%s', err.code)
    console.log('[Info] Program will be exit, please check the DB configuration')
    process.exit(0)
  }

  else {
    console.log('[Info] DB Connection Established')
    setUserList()
  }
})

const setUserList = () => {
  connection.query('select `name`, `email` from `users`', (err, rows) => {
    for (var key in rows) {
      userList[rows[key].name] = rows[key].email
    }
  })
}

const base62 = (id) => {
  var arr = '0123456789qwertyuiopasdfghjklzxcvbnmMNBVCXZLKJHGFDSAPOIUYTREWQ'
  var res = ''
  while (id > 0) {
    res = arr.substring(id % 62, id % 62 + 1) + res
    id = Math.floor(id / 62)
  }
  return res
}

const verifyTracker = (Tracker) => {
  var promise = new Promise((resolve, reject) => {
    const queryParams = [Tracker.id, Tracker.token]
    connection.query('select count(*), `uid` from `trackers` where id = ? and token = ?', queryParams, (err, rows) => {
      if (rows[0]['count(*)'] === 0) {
        resolve({
          ok: false
        })
      }
      else {
        resolve({
          ok: true,
          uid: rows[0].uid
        })
      }
    })
  })

  return promise
}

const genTracker = (uid) => {
  var promise = new Promise((resolve, reject) => {
    const deleteParams = [uid]
    connection.query('delete from `trackers` where `uid` = ?', deleteParams, (err) => {
      if (err) {
        reject(undefined)
        throw err
      }
      var now = new Date()
      var Tracker = {
        id: 'T-' + base62(parseInt(now.getTime() / 1000 + now.getTime() % 1000)),
        token: 'T-' + base62(parseInt(now.getTime() / 10 + now.getTime() % 1000))
      }
      var insertParams = [uid, Tracker.id, Tracker.token]
      connection.query('insert into `trackers` (`uid`, `id`, `token`) values (?, ?, ?)', insertParams, (err) => {
        if (err) {
          reject(undefined)
          throw err
        }
        resolve(Tracker)
      })
    })
  })

  return promise
}

app.post('/api/login', (req, res) => {
  var pwd = encrypt(req.body.pwd)
  const queryParams = [req.body.name, pwd]
  connection.query('select count(*), `uid` from `users` where `name` = ? and pwd = ?', queryParams, async (err, rows) => {
    if (err) {
      res.json({ ok: false })
      throw err
    }
    if (rows[0]['count(*)']) {
      try {
        var Tracker = await genTracker(rows[0].uid)
        res.cookie('tracker-id', Tracker.id)
        res.cookie('tracker-token', Tracker.token)
        res.json({
          ok: true,
          uid: rows[0].uid
        })
      }
      catch (err) {
        res.json({
          ok: false
        })
      }
    }
    else {
      res.json({ ok: false })
    }
  })
})

app.get('/api/user', async (req, res) => {
  if (req.cookies['tracker-id'] !== undefined &&
    req.cookies['tracker-token'] !== undefined) {
    var Tracker = {
      id: req.cookies['tracker-id'],
      token: req.cookies['tracker-token']
    }
    var response = await verifyTracker(Tracker)
    if (response.ok) {
      res.json({
        ok: true,
        name: response.name,
        email: response.email
      })
    }
    else {
      res.json({
        ok: false
      })
    }
  }
  else {
    res.json({
      ok: false
    })
  }
})

server.listen(1333, () => {
  console.log('[Info] Server started')
})